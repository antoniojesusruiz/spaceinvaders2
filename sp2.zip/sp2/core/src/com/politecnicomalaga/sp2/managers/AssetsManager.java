package com.politecnicomalaga.sp2.managers;

public class AssetsManager {
    //Constantes
    public static final String NUMBERS_SPRITES = "numbers/digito";
    public static final String NUMBERS_EXT_SPRITES =".png";

    public static final String ATLAS_FILE = "sp2.atlas";
}
