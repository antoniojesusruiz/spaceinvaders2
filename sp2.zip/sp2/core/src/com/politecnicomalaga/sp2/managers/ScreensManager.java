package com.politecnicomalaga.sp2.managers;

public class ScreensManager {
}
